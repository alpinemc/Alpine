**Spawned Eggs 1.16-1.21.4_r1** (2024 Dec 3)
- fixed for 1.21.4: added spawn egg definitions in minecraft/items


**Spawned Eggs 1.16-1.21.3_r1** (2024 Oct 26)
- added creaking spawn egg
- added textures for the default spawn egg


**Spawned Eggs 1.16-1.21.1_r1** (2024 Oct 9)
- initial release
